#include "Node.h"
/*
Node::operator=(Node ref)
{
	delete[] this;
	Node *temp = new Node();
	*temp = ref;
	return *temp;
}

Find_Node& Find_Node::operator=(Find_Node& ref)
{
	delete[] this;
	Find_Node *temp = new Find_Node();
	temp = &ref;
	return *temp;
}
*/