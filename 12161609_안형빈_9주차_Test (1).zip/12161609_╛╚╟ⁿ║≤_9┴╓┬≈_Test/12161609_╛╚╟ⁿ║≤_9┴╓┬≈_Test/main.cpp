#include "header.h"

int main()
{
	try {
		VendingMachine VM;
		VM.Display();
	}
	catch (exception &e)
	{
		e.what();
	}
	return 0;
}